﻿$("a.fancyPOP910").fancybox({
    'prevEffect': 'none',
    'nextEffect': 'none',
    'autoScale': false,
    'transitionIn': 'none',
    'transitionOut': 'none',
    'width': 875,
    'height': 550,
    'type': 'iframe'
});
