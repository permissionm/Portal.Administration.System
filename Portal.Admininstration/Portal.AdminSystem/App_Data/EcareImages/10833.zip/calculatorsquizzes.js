﻿$("a.quizClass").fancybox({
    'prevEffect': 'none',
    'nextEffect': 'none',
    'autoScale': false,
    'transitionIn': 'none',
    'transitionOut': 'none',
    'width': 580,
    'height': 550,
    'type': 'iframe'
});
$("a.myLinks").fancybox({
    'prevEffect': 'none',
    'nextEffect': 'none',
    'autoScale': false,
    'transitionIn': 'none',
    'transitionOut': 'none',
    'width': 720,
    'height': 550,
    'type': 'iframe'
});
