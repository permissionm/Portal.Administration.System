﻿getBucketList(mguid, membrID, gobcktID, langID, regionID, useThisURL);
