﻿$("#wellPointsFootLink").fancybox({
    'prevEffect': 'none',
    'nextEffect': 'none',
    'autoScale': false,
    'transitionIn': 'none',
    'transitionOut': 'none',
    'width': 700,
    'height': 550,
    'type': 'iframe'
});
