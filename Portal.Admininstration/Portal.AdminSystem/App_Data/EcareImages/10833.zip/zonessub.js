﻿buildSldrKit(ContEntID, sCurrentPage, clientID, useThisURL);
